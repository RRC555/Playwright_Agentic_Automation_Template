# qa-automation-private-masters

**Access-controlled, confidential repository.** This holds the master `*-automation.agent.md`
templates consumed by the `/bootstrap-project` command in the
[agentic-test-automation-template](https://wwwin-github.cisco.com/moramach/agentic-test-automation-template)
framework repo. It must stay **Private** on GitHub with collaborators limited to trusted automation
team members only — never make it public, never fork it into a client/customer-facing repo.

## What's in here

| File | Platform |
|---|---|
| `brownfield-automation.agent.md` | Web/API (Playwright) |
| `mobile-brownfield-automation.agent.md` | iOS/Android (Mobilewright + Mobile MCP) |
| `mac-brownfield-automation.agent.md` | macOS (WDIO + appium-mac2-driver) |
| `windows-brownfield-automation.agent.md` | Windows (WDIO + WinAppDriver) |

Each file is a **reference-only input** for generating a project-specific agent — never copied
verbatim, never read or quoted outside the `/bootstrap-project` workflow. All credentials/URLs
inside them are `${ENV_VAR}` placeholders; there should never be a reason to add a real secret here.

## How this repo is used

In the framework repo, `private/` is listed in `.gitignore` — it is **never** populated by cloning
or forking the framework repo itself. Instead, anyone running `/bootstrap-project` for the first
time must explicitly clone this repo into that folder:

```bash
# from the root of the agentic-test-automation-template checkout
git clone https://wwwin-github.cisco.com/moramach/qa-automation-private-masters.git private
```

Because `private/` is gitignored in the framework repo, cloning a second git repository directly
into it does not conflict with or get tracked by the framework repo's own git history — the nested
`.git` folder and its contents simply stay invisible to the parent repo.

Once cloned, proceed with `/bootstrap-project <slug>` as documented in the framework repo's
[docs/AUTOMATION_COMMANDS_README.md](https://wwwin-github.cisco.com/moramach/agentic-test-automation-template/blob/master/docs/AUTOMATION_COMMANDS_README.md).

## Updating a template

If a master template gains an enhancement (new phase, new quality gate, new tool), edit it here,
commit, and push — then anyone with an existing local `private/` clone just needs to `git pull`
inside that folder to pick up the change before their next `/bootstrap-project` run. See the
framework repo's `docs/AUTOMATION_COMMANDS_README.md` section 2b for the merge process when a
project has already been bootstrapped from an older version of a template.
