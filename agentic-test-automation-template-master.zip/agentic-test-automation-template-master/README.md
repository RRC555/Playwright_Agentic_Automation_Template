﻿# Brownfield Automation Framework — Master Template

A reusable, agent-driven test automation framework, controlled entirely through **GitHub Copilot**.
This repo is the **master template** — it ships the bootstrap tooling, generic master agent
templates, and reusable scaffolding (web, macOS, Windows, mobile). It does **not** contain any
already-bootstrapped project; every new engagement starts from a one-time `/bootstrap-project`
command that generates its own project-specific agent, context, and docs folders.

---

## Onboarding a new project (first thing anyone new to this repo should do)

1. Clone this repo (or create a branch/fork for your project).
2. Populate `private/` — it's gitignored, so cloning/using-this-template does **not** bring it
   along. Clone the access-controlled master-templates repo directly into it:
   ```bash
   git clone https://wwwin-github.cisco.com/moramach/qa-automation-private-masters.git private
   ```
   See [private/README.md](private/README.md) if you need access requested.
3. Copy real credentials into `.env` from [.env.example](.env.example) (never commit `.env`).
4. Run `npm install`.
5. In Copilot Chat, run the one-time bootstrap command for your project:
   ```
   /bootstrap-project <your-project-slug>
   ```
   This reads the matching private master template under `private/` (web by default —
   `brownfield-automation.agent.md`; see [private/README.md](private/README.md) for mac/Windows/
   mobile templates), drafts a generalized project-specific agent, validates it, then generates:
   - `.github/agents/<your-project-slug>-automation.agent.md`
   - `context/<your-project-slug>/{application,domain,framework,project-prompt}.md`
   - `docs/{testcases,plans,reports}/` entries
   - an `initialized: true` record in `config/bootstrap-state.json`
6. From then on, use the repeated commands below for day-to-day work on that project.

See [docs/AUTOMATION_COMMANDS_README.md](docs/AUTOMATION_COMMANDS_README.md) for the full command
reference, TestRail/Jira/Xray sync details, and troubleshooting.

---

## How to Use This Framework

All automation is driven through **GitHub Copilot Chat** — either address the generated
project agent directly or use a slash command:

```
@<project>-automation-agent  Automate AC1 from JIRA-123: verify the sidebar link navigates to /workspaces

/create-testcase <project> CX-1423
/automate <project> TC-101
/execute-tests <project> @smoke
```

No manual scripts, no UI to navigate — the agent reads context, discovers real locators from the
live app, generates production-ready code, and posts results to your test management tool
(TestRail by default; Xray is a reserved `TEST_MANAGEMENT_PROVIDER` toggle, not yet implemented —
see [docs/AUTOMATION_COMMANDS_README.md](docs/AUTOMATION_COMMANDS_README.md#10-xray-sync-future--not-yet-implemented)) automatically.

---

## Bootstrap Workflow & Slash Commands

New projects are onboarded through a one-time `/bootstrap-project` command that generates a
project-specific agent from a private master template, followed by repeated `/create-testcase`,
`/automate`, `/execute-tests`, `/update-automation`, and `/status` commands. See
[docs/AUTOMATION_COMMANDS_README.md](docs/AUTOMATION_COMMANDS_README.md) for the full command
reference, TestRail/Jira/Xray sync details, and troubleshooting.

---

## Available Agents

| Agent | Platform | Purpose |
|---|---|---|
| `<project>-automation-agent` | Web + API (Playwright) | Generated per-project by `/bootstrap-project` — brownfield web/API test generation with TestRail/Xray traceability (provider set via `TEST_MANAGEMENT_PROVIDER` in `.env`) |
| `playwright-test-planner` | Web | Test plan generation from requirements |
| `playwright-test-generator` | Web | Playwright spec generation from a test plan |
| `playwright-test-healer` | Web | Diagnose and fix failing Playwright tests |
| `pr-review` | Any | Generic PR review agent |
| `cli_agent` (`.claude/agents/`) | Any | Browser automation via `playwright-cli` (token-efficient alternative to Playwright MCP) |

The private master templates used to generate a project agent live outside this list — see
[private/README.md](private/README.md) and
[docs/AUTOMATION_COMMANDS_README.md](docs/AUTOMATION_COMMANDS_README.md) for the `/bootstrap-project` workflow.

Each generated project agent operates in automatic phases:

1. Load the relevant `context/<project>/` files
2. Audit existing POM assets to avoid duplication
3. Create test management cases and embed case IDs in every test title (TestRail by default; Xray
   is a reserved toggle — see [docs/AUTOMATION_COMMANDS_README.md](docs/AUTOMATION_COMMANDS_README.md#10-xray-sync-future--not-yet-implemented))
4. Discover real locators from the live app (browser / device / Accessibility Inspector)
5. Generate three files — locators → screen/page object → spec
6. Run tests and post results back to the configured test management tool

The traceability chain produced (TestRail shown; same shape applies once Xray is implemented):

```
Plain English AC  →  TestRail Case ID  →  spec title [Cxxx]  →  CI run posts pass/fail to TestRail
```

---

## Platform Coverage

### Web & API — Playwright

**Config:** `playwright.config.js` / `config/playwright.config.js`
**Context:** `context/<project>/` (created by `/bootstrap-project`)
**Tests:** `src/web/tests/`
**Pages:** `src/web/pages/`
**Locators:** `src/web/locators/`

```bash
npx playwright test src/web/tests/ --config=config/playwright.config.js --grep "@smoke"
npx playwright test src/web/tests/ --config=config/playwright.config.js --grep "@regression"
```

> **PowerShell note:** quote the grep value — unquoted `@smoke` is treated as a PowerShell splat variable.

CI: `.github/workflows/playwright.yml`

### Platform Scaffolding (mac / Windows / mobile)

No project has bootstrapped these platforms yet. The configs and generic base classes below are
kept as ready-to-use scaffolding for whenever a macOS, Windows, or mobile app needs automating —
run `/bootstrap-project` against the matching template in `private/` first.

| Platform | Config | Generic base class | Tests/Screens/Locators |
|---|---|---|---|
| iOS/Android (MobileWright) | `mobilewright.config.mjs` | — | `src/mobile/{tests,screens,locators}/` (empty) |
| macOS (WDIO + mac2) | `wdio.mac.config.js` | `src/mac/screens/mac-base.screen.js` | `src/mac/{tests,screens,locators}/` |
| Windows (WDIO + WinAppDriver) | `wdio.windows.config.js` | `src/windows/screens/windows-base.screen.js` | `src/windows/{tests,screens,locators}/` |

---

## CI/CD Workflows

| Workflow | Platform | Runner | Schedule |
|---|---|---|---|
| `playwright.yml` | Web + API | `ubuntu-latest` | push / PR / manual |
| `deploy-ui.yml` | Workflow dashboard (`ui/`) | — | — |
| `pr-review.yml` | Any | — | PR |
| `copilot-setup-steps.yml` | Copilot coding agent environment | — | — |

`playwright.yml` produces:
- HTML test report artifact (30-day retention)
- Dark-theme HTML email via `dawidd6/action-send-mail`
- A test management run with per-test pass/fail results posted automatically — TestRail is active
  today; Xray is a reserved `TEST_MANAGEMENT_PROVIDER` toggle with no reporter implemented yet
- PR comment with run summary and artifact links
- GitHub Actions step summary with pass/fail metrics

**Required GitHub Secrets:**

| Secret | Used by |
|---|---|
| `EMAIL_USERNAME`, `EMAIL_PASSWORD`, `EMAIL_TO` | `playwright.yml` |
| `TEST_MANAGEMENT_PROVIDER` | `playwright.yml` — `TESTRAIL` (default) or `XRAY` (reserved) |
| `TESTRAIL_HOST`, `TESTRAIL_USER`, `TESTRAIL_API_KEY`, `TESTRAIL_PROJECT_ID`, `TESTRAIL_SUITE_ID` | `playwright.yml` (active when provider is `TESTRAIL`) |
| `XRAY_CLIENT_ID`, `XRAY_CLIENT_SECRET`, `XRAY_BASE_URL`, `XRAY_PROJECT_KEY` | Reserved — not yet consumed by any reporter |
| `ANTHROPIC_API_KEY` | `playwright.yml` |

---

## Context Files

Each project gets its own `context/<project>/` folder, created by `/bootstrap-project`, which
agents read before writing any code:

```
context/
  <project>/      application.md, framework.md, domain.md, project-prompt.md
```

---

## Agents Directory

```
.github/agents/
  <project>-automation.agent.md       Generated per project by /bootstrap-project
  playwright-test-planner.agent.md    Test plan generation
  playwright-test-generator.agent.md  Playwright spec generation
  playwright-test-healer.agent.md     Test failure diagnosis and repair
  pr-review.agent.md                  Generic PR review agent

.claude/agents/
  cli_agent.agent.md                  Browser automation via playwright-cli

private/                              Confidential master templates (gitignored, see private/README.md)
  brownfield-automation.agent.md
  mobile-brownfield-automation.agent.md
  mac-brownfield-automation.agent.md
  windows-brownfield-automation.agent.md
```

---

## Repository Structure

```text
src/
  web/                    Playwright web tests, page objects, locators
  mobile/                 MobileWright scaffolding (empty until a project is bootstrapped)
  mac/                    macOS WDIO scaffolding (empty except generic mac-base.screen.js)
  windows/                Windows WDIO scaffolding (empty except generic windows-base.screen.js)
  shared/
    core/                 AI engine, agents, MCP, test runner
    data/                 Shared test data (TD.*) — populated per project by /automate
    fixtures/             Extended test fixtures
    integrations/         Jira, TestRail (active), Xray (reserved — not yet implemented), logging
    mcp/                  MCP clients and server
    traceability/         Test management case map JSON files (TestRail case IDs today) — empty, populated per project

config/
  playwright.config.js    Playwright config (baseURL defaults to http://localhost:3000)
  platform/
    mac.config.js         macOS Appium platform config template (port 4724)
    windows.config.js     Windows Appium platform config template (port 4723)
    mobile.config.js      Mobile platform config template

context/                  Project context files — populated per project by /bootstrap-project

.github/agents/           GitHub Copilot agent definitions
.github/prompts/          Slash commands (/bootstrap-project, /create-testcase, /automate, ...)
.github/workflows/        CI/CD pipelines
private/                  Confidential master agent templates (gitignored)
docs/                     Bootstrap/command reference, per-project testcases/plans/reports

scripts/
  generate-email.js              Playwright HTML email generator
  start-mobilecli.sh             Generic mobilecli server starter (mobile scaffolding)
  bootstrap/                     Bootstrap orchestrator, validator, scaffolder

wdio.mac.config.js        macOS WDIO config (mac2 driver, port 4724) — scaffolding, unused until bootstrapped
wdio.windows.config.js    Windows WDIO config (WinAppDriver, port 4723) — scaffolding, unused until bootstrapped
mobilewright.config.mjs   MobileWright config (Android/iOS) — scaffolding, unused until bootstrapped
playwright.config.js      Root Playwright config (web/API)
```

---

## npm Scripts Reference

```bash
# ─── Web (Playwright) ──────────────────────────────────────────────────────
npx playwright test                              # all web tests
npx playwright test --grep "@smoke"              # smoke only

# ─── Mobile (MobileWright) — scaffolding, no target app yet ───────────────
npx mobilewright test <spec-file>

# ─── macOS (WDIO + mac2) — scaffolding, no target app yet ─────────────────
npm run test:mac
npm run mac:show-report

# ─── Windows (WDIO + WinAppDriver) — scaffolding, no target app yet ───────
npm run test:windows
npm run windows:show-report
```

---

## Security Notes

- `private/**` and `.tmp/**` are gitignored — never remove them from `.gitignore`.
- Never hardcode Jira/TestRail/Xray credentials or internal URLs anywhere under `.github/agents/`,
  `.github/prompts/`, or `context/` — always use `${ENV_VAR}` placeholders resolved from `.env`.
- If a real secret is ever committed or pasted into a shared file/chat, rotate it immediately — do
  not rely on deleting the text after the fact.
