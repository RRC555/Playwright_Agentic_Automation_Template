/**
 * Idempotent, deterministic filesystem scaffolding for a newly bootstrapped project.
 * Never overwrites existing files — only fills in what is missing.
 *
 * Usage (CLI):   node scripts/bootstrap/scaffold-project.js <project-slug>
 * Usage (lib):   const { scaffoldProject } = require('./scaffold-project');
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');

const CONTEXT_FILES = {
  'application.md': (project) => `# ${project} — Application Context\n\n> Fill in: target URL(s), routes, known selectors, environment notes.\n`,
  'domain.md': (project) => `# ${project} — Domain Context\n\n> Fill in: business rules, acceptance-criteria patterns, edge cases.\n`,
  'framework.md': (project) => `# ${project} — Framework Context\n\n> Fill in: POM conventions, file naming, assertion rules, config details.\n`,
  'project-prompt.md': (project) => `# ${project} — Always-On Guardrails\n\n> Fill in: rules injected into every automation request for this project.\n`,
};

const DOC_DIRS = ['testcases', 'plans', 'reports'];

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    return true;
  }
  return false;
}

function scaffoldProject(projectSlug) {
  const created = [];

  const contextDir = path.join(ROOT, 'context', projectSlug);
  if (ensureDir(contextDir)) created.push(contextDir);
  for (const [fileName, template] of Object.entries(CONTEXT_FILES)) {
    const filePath = path.join(contextDir, fileName);
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, template(projectSlug), 'utf8');
      created.push(filePath);
    }
  }

  for (const sub of DOC_DIRS) {
    const docDir = path.join(ROOT, 'docs', sub);
    if (ensureDir(docDir)) created.push(docDir);
  }

  return created;
}

if (require.main === module) {
  const [, , projectSlug] = process.argv;
  if (!projectSlug) {
    console.error('Usage: node scaffold-project.js <project-slug>');
    process.exit(2);
  }
  const created = scaffoldProject(projectSlug);
  console.log(created.length ? `Created:\n${created.join('\n')}` : 'Nothing to create — already scaffolded.');
}

module.exports = { scaffoldProject };
