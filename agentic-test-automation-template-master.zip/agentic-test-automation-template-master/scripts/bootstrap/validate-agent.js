/**
 * Deterministic validator for a generated project agent (.agent.md) before it is
 * allowed to replace the file under .github/agents/.
 *
 * Usage (CLI):   node scripts/bootstrap/validate-agent.js <path-to-agent.md> <project-slug>
 * Usage (lib):   const { validateAgent } = require('./validate-agent');
 */
'use strict';
const fs = require('fs');

// Tokens that indicate the private master template leaked through instead of being generalized.
const FORBIDDEN_TOKENS = [
  'starhub',
  'brownfield-automation-agent',
  'mobile-brownfield-automation-agent',
  'master brownfield automation agent',
  'ascendion.com',
  'ascendionqesmoketest',
  'ascendionconfluence',
];

// A raw, non-placeholder email address should never be hardcoded in a shareable agent file.
const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;

const REQUIRED_FRONTMATTER_FIELDS = ['name:', 'description:'];

function splitFrontmatter(content) {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/);
  if (!match) return null;
  return { frontmatter: match[1], body: match[2] };
}

function validateAgent(content, projectSlug) {
  const errors = [];
  const warnings = [];

  const parts = splitFrontmatter(content);
  if (!parts) {
    errors.push('Missing or malformed YAML frontmatter (must start/end with --- lines).');
    return { valid: false, errors, warnings };
  }
  const { frontmatter, body } = parts;

  for (const field of REQUIRED_FRONTMATTER_FIELDS) {
    if (!frontmatter.includes(field)) {
      errors.push(`Frontmatter missing required field "${field}"`);
    }
  }

  const lowerAll = content.toLowerCase();
  for (const token of FORBIDDEN_TOKENS) {
    if (lowerAll.includes(token.toLowerCase())) {
      errors.push(`Forbidden token found (leaked from private master template): "${token}"`);
    }
  }

  const emailMatches = content.match(EMAIL_REGEX) || [];
  const realEmails = emailMatches.filter((e) => !e.startsWith('${'));
  if (realEmails.length) {
    errors.push(`Hardcoded email address(es) found, use \${ENV_VAR} placeholders instead: ${realEmails.join(', ')}`);
  }

  if (projectSlug && !lowerAll.includes(projectSlug.toLowerCase().replace(/-/g, ' ')) &&
      !lowerAll.includes(projectSlug.toLowerCase())) {
    warnings.push(`Project identifier "${projectSlug}" was not found anywhere in the agent file.`);
  }

  const headingCount = (body.match(/^##\s+/gm) || []).length;
  if (headingCount < 3) {
    warnings.push(`Only ${headingCount} "##" section headings found — agent body looks too thin.`);
  }

  if (body.trim().length < 500) {
    errors.push('Agent body is too short to be a real workflow definition (< 500 chars).');
  }

  return { valid: errors.length === 0, errors, warnings };
}

if (require.main === module) {
  const [, , filePath, projectSlug] = process.argv;
  if (!filePath) {
    console.error('Usage: node validate-agent.js <path-to-agent.md> <project-slug>');
    process.exit(2);
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const result = validateAgent(content, projectSlug);
  console.log(JSON.stringify(result, null, 2));
  process.exit(result.valid ? 0 : 1);
}

module.exports = { validateAgent };
