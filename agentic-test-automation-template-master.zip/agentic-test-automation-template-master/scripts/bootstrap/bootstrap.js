/**
 * One-time bootstrap orchestrator.
 *
 * Expects an AI/LLM step to have already drafted a generalized project agent at:
 *   .tmp/<project-slug>-automation.agent.md
 * (derived from the private master template under private/, never copied verbatim).
 *
 * This script performs only the deterministic, repeatable parts:
 *   1. Validate the draft agent (validate-agent.js)
 *   2. Atomically move it into .github/agents/<project-slug>-automation.agent.md
 *   3. Scaffold context/docs folders for the project (scaffold-project.js)
 *   4. Record success in config/bootstrap-state.json
 *
 * Usage: node scripts/bootstrap/bootstrap.js <project-slug> [--force]
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { validateAgent } = require('./validate-agent');
const { scaffoldProject } = require('./scaffold-project');

const ROOT = path.resolve(__dirname, '..', '..');
const STATE_PATH = path.join(ROOT, 'config', 'bootstrap-state.json');

function readState() {
  if (!fs.existsSync(STATE_PATH)) return { bootstrapVersion: '1.0', projects: {} };
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}

function writeState(state) {
  fs.mkdirSync(path.dirname(STATE_PATH), { recursive: true });
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2) + '\n', 'utf8');
}

function bootstrap(projectSlug, { force = false } = {}) {
  const state = readState();
  const existing = state.projects[projectSlug];
  if (existing && existing.initialized && !force) {
    return { ok: false, reason: `Project "${projectSlug}" is already bootstrapped. Pass --force to regenerate.` };
  }

  const tmpPath = path.join(ROOT, '.tmp', `${projectSlug}-automation.agent.md`);
  if (!fs.existsSync(tmpPath)) {
    return { ok: false, reason: `Draft agent not found at ${path.relative(ROOT, tmpPath)}. Generate it first.` };
  }

  const content = fs.readFileSync(tmpPath, 'utf8');
  const result = validateAgent(content, projectSlug);
  if (!result.valid) {
    return { ok: false, reason: 'Validation failed', errors: result.errors, warnings: result.warnings };
  }

  const targetPath = path.join(ROOT, '.github', 'agents', `${projectSlug}-automation.agent.md`);
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  fs.renameSync(tmpPath, targetPath);

  const created = scaffoldProject(projectSlug);

  state.projects[projectSlug] = {
    agent: path.relative(ROOT, targetPath).replace(/\\/g, '/'),
    initialized: true,
    validated: true,
    framework: 'playwright',
    createdAt: existing && existing.createdAt ? existing.createdAt : new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  writeState(state);

  return { ok: true, agent: targetPath, created, warnings: result.warnings };
}

if (require.main === module) {
  const args = process.argv.slice(2);
  const force = args.includes('--force');
  const projectSlug = args.find((a) => !a.startsWith('--'));
  if (!projectSlug) {
    console.error('Usage: node bootstrap.js <project-slug> [--force]');
    process.exit(2);
  }
  const result = bootstrap(projectSlug, { force });
  console.log(JSON.stringify(result, null, 2));
  process.exit(result.ok ? 0 : 1);
}

module.exports = { bootstrap };
