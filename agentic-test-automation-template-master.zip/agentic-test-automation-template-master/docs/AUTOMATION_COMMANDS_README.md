# Automation Commands — Bootstrap, Test Cases, Scripts, Execution & TestRail/Xray/Jira Sync

This is the detailed, project-agnostic guide to the **bootstrap → agent → slash command** workflow
built around `scripts/bootstrap/` and `.github/prompts/`. It documents every command, what it
creates, how it talks to TestRail / Jira / Xray, and how to troubleshoot it.

For the general multi-platform framework overview (all agents, all platforms), see the root
[README.md](../README.md). This document focuses only on the bootstrap + command layer.

---

## 1. Architecture at a glance

```
private/<name>-automation.agent.md   (confidential master template — gitignored, never shared)
        │  read-only reference, never copied verbatim
        ▼
.tmp/<project>-automation.agent.md   (draft, generated per project)
        │  node scripts/bootstrap/validate-agent.js
        ▼
.github/agents/<project>-automation.agent.md   (shareable, project-specific agent)
        │  node scripts/bootstrap/scaffold-project.js
        ▼
context/<project>/*.md   +   docs/{testcases,plans,reports}/
        │
        ▼
config/bootstrap-state.json   ("initialized": true for <project>)
        │
        ▼
Repeated commands: /create-testcase → /automate → /execute-tests → /update-automation → /status
```

- `private/` and `.tmp/` are listed in `.gitignore` — the master template and in-flight drafts never
  get committed.
- `config/bootstrap-state.json` is the single source of truth for "has this project been
  bootstrapped?". Every repeated command checks it first and refuses to run if it's not `true`.

---

## 2. One-time: `/bootstrap-project`

**File:** [.github/prompts/bootstrap-project.prompt.md](../.github/prompts/bootstrap-project.prompt.md)

```
/bootstrap-project cx-labs
```

What happens:
1. Copilot reads `private/brownfield-automation.agent.md` (reference only — never quoted back to you).
2. It drafts a generalized agent to `.tmp/cx-labs-automation.agent.md`, with all credentials/URLs
   written as `${ENV_VAR}` placeholders — never hardcoded values.
3. You (or the agent) run the deterministic validator:
   ```bash
   node scripts/bootstrap/validate-agent.js .tmp/cx-labs-automation.agent.md cx-labs
   ```
   This blocks the run if it finds: missing frontmatter, forbidden tokens leaked from the master
   template (e.g. other client names), hardcoded email addresses, or a body that's too thin.
4. Run the orchestrator:
   ```bash
   node scripts/bootstrap/bootstrap.js cx-labs
   ```
   This atomically:
   - moves the validated draft to `.github/agents/cx-labs-automation.agent.md`
   - scaffolds `context/cx-labs/{application,domain,framework,project-prompt}.md` and
     `docs/{testcases,plans,reports}/` — **idempotent**, never overwrites existing files
   - writes/updates `config/bootstrap-state.json`

Re-running an already-bootstrapped project requires `--force`:
```bash
node scripts/bootstrap/bootstrap.js cx-labs --force
```

**Expected error if `.tmp/` is empty:**
```json
{ "ok": false, "reason": "Draft agent not found at .tmp\\cx-labs-automation.agent.md. Generate it first." }
```
This is not a bug — it means the draft was already consumed by a previous successful run. Draft a
new `.tmp/<project>-automation.agent.md` before re-running.

---

## 2b. Pulling in an enhanced master template later (merge, not overwrite)

The master template (e.g. `private/brownfield-automation.agent.md`) is typically removed from a
client repo once bootstrap succeeds — see [private/README.md](../private/README.md). If your
canonical master later gains an enhancement (new phase, new quality gate, new tool), **do not**
just drop the updated master into `private/` and re-run `bootstrap.js --force` blindly: it does a
straight file move with no merge logic, so it will silently wipe any project-specific sections
that accumulated in `.github/agents/<project>-automation.agent.md` since the last bootstrap (e.g.
CX Labs' "CX LABS-SPECIFIC NOTES", "SETUP NOTE", test directory structure).

Correct process:
1. Copy the updated master template into `private/<name>-automation.agent.md`.
2. Ask the agent to **merge**, not regenerate: read the updated master *and* the current
   `.github/agents/<project>-automation.agent.md` side by side, carry over only what's new/changed
   in the master (new phases, rules, tool entries), and keep every project-specific section intact.
3. Write the merged result to `.tmp/<project>-automation.agent.md`, then run the normal validate +
   `bootstrap.js <project> --force` steps from section 2.
4. Optionally delete the master from `private/` again afterward — it's gitignored either way.

---

## 3. Repeated: `/create-testcase`

**File:** [.github/prompts/create-testcase.prompt.md](../.github/prompts/create-testcase.prompt.md)

```
/create-testcase CX-1423
/create-testcase checkout payment validation
```

- Checks `config/bootstrap-state.json` first — refuses to run if the project isn't bootstrapped.
- Loads `context/cx-labs/*.md`, fetches the Jira story via `jira/get_issue` if a key was given.
- Cross-checks `src/shared/traceability/testrail-case-map.json` and existing specs so it never
  creates a duplicate case for an AC that's already covered.
- Writes structured test cases (ID, Scenario, Preconditions, Test Data, Steps, Expected Results,
  Priority, Automation Candidate, Tags) to `docs/testcases/<story-key-or-slug>.md`.
- Does **not** generate automation code — that's `/automate`.

---

## 4. Repeated: `/automate`

**File:** [.github/prompts/automate.prompt.md](../.github/prompts/automate.prompt.md)

```
/automate TC-101 TC-102
/automate docs/testcases/CX-1423.md
```

Runs the full 8-phase workflow defined in `.github/agents/<project>-automation.agent.md`:

| Phase | What it does |
|---|---|
| 1 | Load `context/<project>/*.md` |
| 2 | Audit existing locators/pages/specs — reuse before creating |
| 3 | Push new/changed test cases to TestRail, embed `[Cxxx]` IDs |
| 4 | Live-inspect the app (`browser_navigate`, `browser_snapshot`, etc.) for real selectors |
| 5 | Decide UI / API / both |
| 6 | Generate locator → page object → spec (three files, POM structure) |
| 7 | Quality gates checklist before saving |
| 8 | Run the new spec, fix failures, confirm pass |

Output lands under `src/web/locators/`, `src/web/pages/`, `src/web/tests/<area>/`.

---

## 5. Repeated: `/execute-tests`

**File:** [.github/prompts/execute-tests.prompt.md](../.github/prompts/execute-tests.prompt.md)

```
/execute-tests TC-101
/execute-tests src/web/tests/nav/cx-home-nav.spec.js
/execute-tests @smoke
```

- Resolves the target to a spec file/tag via `testrail-case-map.json` if needed.
- Confirms `playwright/.auth/<project>-storageState.json` exists before running anything that
  requires authentication (never scripts the SSO/MFA login itself).
- Runs:
  ```bash
  npx playwright test <resolved-target> --config=config/playwright.config.js
  ```
- `testrail-reporter.js` (wired into `config/playwright.config.js`) automatically posts pass/fail
  per `[Cxxx]` case — no manual posting needed.
- On failure, classifies the failure type and offers to invoke the healer:
  ```bash
  node src/shared/helpers/self-healing.js --queue test-results/healing-queue.json
  ```

---

## 6. Repeated: `/update-automation`

**File:** [.github/prompts/update-automation.prompt.md](../.github/prompts/update-automation.prompt.md)

```
/update-automation TC-104
```

Calculates the delta between the current requirement and the existing test case/implementation,
then patches only the impacted locator/page method/assertion/test-data entry — never a full
regeneration. Re-runs only the impacted spec afterward.

---

## 7. `/status`

**File:** [.github/prompts/status.prompt.md](../.github/prompts/status.prompt.md)

```
/status cx-labs
```

Read-only report: bootstrap state, test case count, spec count, and two gap lists —
test cases with no `[Cxxx]` spec yet (automation gap), and specs with a `[Cxxx]` prefix missing
from `testrail-case-map.json` (traceability gap).

---

## 8. TestRail sync

Config lives in `.env` (never commit real values — `.env` is gitignored):

```
TEST_MANAGEMENT_PROVIDER=TESTRAIL
TESTRAIL_HOST=<your TestRail instance URL>
TESTRAIL_USER=<service account email>
TESTRAIL_API_KEY=<api key>
TESTRAIL_PROJECT_ID=<id>
TESTRAIL_SUITE_ID=<id>
TESTRAIL_SECTION_ID=<id>
```

Per-project overrides (e.g. CX Labs doesn't have dedicated IDs yet) use a `<PROJECT>_TESTRAIL_*`
prefix and stay commented out until TestRail provisions them:
```
# CX_LABS_TESTRAIL_PROJECT_ID=TBD
# CX_LABS_TESTRAIL_SUITE_ID=TBD
# CX_LABS_TESTRAIL_SECTION_ID=TBD
```

Sync flow:
```
jira/get_issue → ACs
    ↓ testrail/add_case (Phase 3)
TestRail case Cxxx
    ↓ embedded as [Cxxx] in the spec title (Phase 3.3)
npx playwright test ... (Phase 8 / /execute-tests)
    ↓ testrail-reporter.js (automatic, config/playwright.config.js)
TestRail run — pass/fail posted per case
```

Manual/fallback scripts (only if the MCP server is unavailable):
```bash
node src/shared/integrations/push-to-testrail.js
node src/shared/integrations/get-testrail-sections.js
```

---

## 9. Jira sync

Config lives in `.env`:
```
JIRA_HOST=<your Jira instance URL>
JIRA_EMAIL=<service account email>
JIRA_API_TOKEN=<api token>
JIRA_PROJECT_KEY=<project key>
```

The agent calls `jira/get_issue` to fetch stories/ACs and `jira/add_comment` to post the traceability
summary (`[Cxxx]` case IDs + pass status) back to the story after Phase 8 tests pass. Manual/fallback
scripts:
```bash
node src/shared/integrations/fetch-jira-story.js
node src/shared/integrations/test-jira-connection.js
node src/shared/integrations/update-jira-results.js
```

---

## 10. Xray sync

`TEST_MANAGEMENT_PROVIDER=XRAY` is fully wired via `src/shared/integrations/xray-integration.js`,
`push-to-xray.js`, and `xray-reporter.js` (the Xray counterpart to `testrail-integration.js` /
`push-to-testrail.js` / `testrail-reporter.js`). To use it:
1. Create an Xray API Key (Client ID/Secret) from Xray Cloud's admin screen (OAuth2 client
   credentials, not a personal token).
2. Add to `.env`:
   ```
   XRAY_CLIENT_ID=
   XRAY_CLIENT_SECRET=
   XRAY_BASE_URL=https://xray.cloud.getxray.app
   XRAY_PROJECT_KEY=
   ```
3. Set `TEST_MANAGEMENT_PROVIDER=XRAY`.
4. Append one entry per acceptance criterion to `src/shared/traceability/xray-test-cases.json`
   (same `{ specTitle, title, preconditions, steps, expected, jiraRef }` shape as
   `testrail-test-cases.json`), then run:
   ```bash
   node src/shared/integrations/push-to-xray.js
   ```
   This creates/updates Manual Test issues in Xray and writes
   `src/shared/traceability/xray-case-map.json` (`specTitle → { issueId, key }`).
5. Embed the returned issue key in the spec title as `[PROJECT-123]` (the Xray equivalent of
   TestRail's `[Cxxx]` prefix). `xray-reporter.js` is already wired into
   `config/playwright.config.js` and posts PASSED/FAILED/TODO to a new Xray Test Execution after
   every run — no manual step needed once the case map exists.
6. There is no Xray MCP server, so the agent always uses these Node scripts directly for this
   provider (not a fallback) — see `.github/agents/<project>-automation.agent.md` Phase 3.2b.

---

## 11. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Draft agent not found at .tmp\\...` | `.tmp/` draft was already moved by a prior successful run | Draft a new `.tmp/<project>-automation.agent.md`, then re-run |
| `Project "<x>" is already bootstrapped` | `config/bootstrap-state.json` already has `initialized: true` | Pass `--force` if you intend to regenerate |
| Validation fails with "Forbidden token found" | The draft leaked wording/IDs from the private master template | Re-generalize that section, remove the literal token |
| Validation fails with "Hardcoded email address(es) found" | A real email landed in the draft instead of `${ENV_VAR}` | Replace with a placeholder and move the real value to `.env` |
| `/execute-tests` can't authenticate | Missing `playwright/.auth/<project>-storageState.json` | Complete the SSO/MFA login once in a headed browser and save storage state — never script this step |

---

## 12. Security notes

- `private/**` and `.tmp/**` are gitignored — never remove them from `.gitignore`.
- Never hardcode Jira/TestRail/Xray credentials or internal URLs anywhere under `.github/agents/`,
  `.github/prompts/`, or `context/` — always use `${ENV_VAR}` placeholders resolved from `.env`.
- If a real secret is ever committed or pasted into a shared file/chat, rotate it immediately — do
  not rely on deleting the text after the fact.
