---
description: Apply a targeted delta update to an existing test case's automation after a requirement change — never a full regeneration.
agent: agent
argument-hint: "<project slug> <test case ID to update>"
---

# /update-automation

## Argument
The text following `/update-automation` is the test case ID or `docs/testcases/` file to update
(e.g. `TC-104`). If omitted, ask the user for it.

## Preconditions
Read `config/bootstrap-state.json` and resolve `<project>`: if exactly one project has
`initialized: true`, use it; if more than one, ask the user which project.

## Steps
1. Read the existing test case under `docs/testcases/` and the existing implementation
   (locator/page object/spec/test-data) that covers it.
2. Re-fetch the current requirement (Jira story or updated plain-English description) and diff it
   against the existing test case to calculate exactly what changed.
3. Update only the impacted pieces — locator, page object method, spec assertions, or test data —
   never regenerate the whole file from scratch.
4. Update `docs/testcases/` and `src/shared/traceability/testrail-case-map.json` if the AC text or
   case ID changed.
5. Run the impacted spec only (`/execute-tests <testcase>`) to confirm the update, not the full suite.
