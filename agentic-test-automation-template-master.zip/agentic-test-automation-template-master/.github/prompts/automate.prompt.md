---
description: Generate Playwright automation from approved test cases, reusing existing page objects/locators/fixtures.
agent: agent
argument-hint: "<project slug> <test case ID(s) or docs/testcases/ file>"
---

# /automate

## Argument
The text following `/automate` is one or more test case IDs/files (e.g. `TC-101 TC-102` or
`docs/testcases/CX-1423.md`). If omitted, ask the user for it.

## Preconditions
Read `config/bootstrap-state.json` and resolve `<project>`: if exactly one project has
`initialized: true`, use it; if more than one, ask the user which project; if none, stop and tell
the user to run `/bootstrap-project` first.

## Steps
1. Resolve the approved test case(s) from `docs/testcases/`.
2. Follow the full workflow in `.github/agents/<project>-automation.agent.md` (Phases 1–8): load
   context, audit existing assets, establish TestRail traceability, live-inspect the app, decide
   UI/API/both, generate POM-structured code, apply quality gates, verify with the test runner.
3. Reuse existing page objects, locators, fixtures, and test-data constants — only create new
   abstractions when there is genuinely no existing coverage.
4. Perform syntax/lint validation and a Playwright `--list` dry run before executing anything.
5. Do not execute destructive flows without explicit user approval.
