---
description: Generate test cases from a requirement or user story and store them under docs/testcases/.
agent: agent
argument-hint: "<project slug> <Jira key or plain-English requirement>"
---

# /create-testcase

## Argument
The text following `/create-testcase` is a Jira key (e.g. `CX-1423`) or a plain-English requirement
(e.g. `checkout payment validation`). If omitted, ask the user for it.

## Preconditions
Read `config/bootstrap-state.json` and resolve `<project>`: if exactly one project has
`initialized: true`, use it; if more than one, ask the user which project; if none, stop and tell
the user to run `/bootstrap-project` first.

## Steps
1. Load project context from `context/<project>/` (application.md, domain.md, framework.md, project-prompt.md).
2. Fetch the story via Jira MCP if a key is given; otherwise parse the plain-English requirement directly.
3. Audit `docs/testcases/` and `src/shared/traceability/testrail-case-map.json` for existing coverage —
   never duplicate a test case that already exists for the same AC.
4. Generate test cases containing: Test Case ID, Scenario, Preconditions, Test Data, Steps,
   Expected Results, Priority, Automation Candidate, Tags.
5. Store output under `docs/testcases/<story-key-or-slug>.md`.
6. Do **not** generate automation scripts in this command — that is `/automate`.
