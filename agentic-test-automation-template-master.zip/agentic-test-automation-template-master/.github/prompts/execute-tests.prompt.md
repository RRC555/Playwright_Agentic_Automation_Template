---
description: Run the Playwright suite (or a subset) for a test case / spec, capture the report, and classify failures.
agent: agent
argument-hint: "<project slug> <test case ID, spec path, or @tag>"
---

# /execute-tests

## Argument
The text following `/execute-tests` is a test case ID, spec path, or tag (e.g. `TC-101`,
`src/web/tests/nav/acme-home-nav.spec.js`, or `@smoke`). If omitted, ask the user for it.

## Preconditions
Read `config/bootstrap-state.json` and resolve `<project>`: if exactly one project has
`initialized: true`, use it; if more than one, ask the user which project; if none, stop and tell
the user to run `/bootstrap-project` first.

## Steps
1. Resolve `target` → spec file(s) using `src/shared/traceability/testrail-case-map.json` if a
   TestRail/testcase ID was given.
2. Confirm `playwright/.auth/<project>-storageState.json` exists if the app requires auth — if
   missing, stop and tell the user to complete the login once to generate it (never attempt to
   script a login that involves SSO/MFA).
3. Run:
   ```bash
   npx playwright test <resolved-spec-or-tag> --config=config/playwright.config.js
   ```
4. Capture the HTML report (`playwright-report/`) and summarize pass/fail counts.
5. If failures occurred, classify them (assertion mismatch, timeout, selector not found, flaky) and
   ask the user whether to invoke the healer (`node src/shared/helpers/self-healing.js --queue test-results/healing-queue.json`)
   before re-running.
6. `testrail-reporter.js` posts results automatically — do not post results manually.
