---
description: Report bootstrap state and automation coverage summary for a project.
agent: agent
argument-hint: "<project slug>"
---

# /status

## Argument
The text following `/status` is the project slug. If omitted, read `config/bootstrap-state.json`:
if exactly one project exists, default to it; if more than one, ask the user which project.

## Steps
1. Read `config/bootstrap-state.json` and report whether `<project>` is initialized, which agent
   file backs it, and when it was created/last updated.
2. Count test cases under `docs/testcases/`, specs under `src/web/tests/`, and entries in
   `src/shared/traceability/testrail-case-map.json`.
3. Report any test cases that have no matching `[Cxxx]` spec yet (automation gap), and any specs
   whose `[Cxxx]` prefix is missing from the case map (traceability gap).
4. Present a concise summary table — do not modify any files in this command.
