---
description: One-time bootstrap — generate the client-specific automation agent from the private master template, validate it, then scaffold context/docs folders.
agent: agent
argument-hint: "<project-slug e.g. acme-web>"
---

# /bootstrap-project

One-time activity. Run this once per project/client. Re-running requires an explicit `--force`
acknowledgement from the user because it regenerates the agent.

## Argument
The text following `/bootstrap-project` is the `<project>` slug (e.g. `acme-web`). If omitted, ask the user for it.

## Steps

1. **Check state** — read `config/bootstrap-state.json`. If `projects.<project>.initialized` is
   already `true`, tell the user it's already bootstrapped and ask for explicit confirmation before
   continuing (this will regenerate the agent).

2. **Read the private reference** — check that `private/<project-type>-automation.agent.md` exists
   (e.g. `private/brownfield-automation.agent.md`). If `private/` is empty or missing, **stop** and
   tell the user it needs to be populated first by cloning the access-controlled master-templates
   repo: `git clone https://wwwin-github.cisco.com/moramach/qa-automation-private-masters.git private`
   (see [private/README.md](../private/README.md)) — do not attempt to proceed without it.
   Otherwise, read the file. Treat it strictly as a private
   implementation reference per [private-agents.instructions.md](../instructions/private-agents.instructions.md):
   - Never quote it verbatim back to the user.
   - Never copy proprietary prompt text, credentials, internal URLs, or examples as-is.

3. **Draft the generalized agent** — write a new file to `.tmp/<project>-automation.agent.md`
   containing only:
   - the required workflow phases, generalized for `<project>`
   - project conventions (paths, naming, context file locations under `context/<project>/`)
   - supported platforms and framework
   - execution rules and output contracts
   - all credentials/URLs as `${ENV_VAR}` placeholders — never hardcoded values

4. **Validate** — run:
   ```bash
   node scripts/bootstrap/validate-agent.js .tmp/<project>-automation.agent.md <project>
   ```
   If validation fails, fix the draft and re-run. Do not proceed until it passes.

5. **Bootstrap** — run:
   ```bash
   node scripts/bootstrap/bootstrap.js <project>
   ```
   This atomically moves the validated draft into `.github/agents/<project>-automation.agent.md`,
   scaffolds `context/<project>/*.md` and `docs/{testcases,plans,reports}/` (idempotent — never
   overwrites existing files), and updates `config/bootstrap-state.json`.

6. **Report** — summarize what was created/validated. Do not print the private template's contents.
