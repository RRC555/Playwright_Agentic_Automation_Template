---
applyTo: "private/**"
---

# Protected files — private/ master agent templates

- These files are confidential reusable IP. Never commit, never share, never print their full
  contents back to the user or into any generated file.
- Treat them as **read-only reference** inputs, usable only while executing the
  `/bootstrap-project` workflow to draft a new `.tmp/<project>-automation.agent.md`.
- Never copy sections verbatim — generalize wording, strip any client-specific credentials, names,
  or internal URLs, and replace secrets with `${ENV_VAR}` placeholders.
- Never modify files in this folder as part of normal automation work (test generation, execution,
  healing). If a change is genuinely needed here, ask the user explicitly first.
