// === FILE: mobilewright.config.mjs ===
import { defineConfig } from 'mobilewright';

export default defineConfig({
  platform: 'android',
  url: 'ws://127.0.0.1:12000/ws',
  autoStart: false,
  bundleId: process.env.MOBILE_BUNDLE_ID || '', // set once a Cisco mobile app target is bootstrapped
  timeout: 30000,
  testDir: './src/mobile/tests',
  testMatch: '**/*.spec.{js,mjs}',
  outputDir: './test-results/artifacts',
  reporter: [
    ['list'],
    ['html', { outputFolder: 'src/mobile/reports/html', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
    ['./src/shared/integrations/testrail-reporter.js']
  ],
  retries: 0,
});
