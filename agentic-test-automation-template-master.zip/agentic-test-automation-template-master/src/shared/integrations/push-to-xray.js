/**
 * Push acceptance-criteria-derived test cases to Xray (Jira Cloud).
 *
 * Usage:
 *   node src/shared/integrations/push-to-xray.js
 *
 * Required env vars (.env):
 *   XRAY_CLIENT_ID=...
 *   XRAY_CLIENT_SECRET=...
 *   XRAY_BASE_URL=https://xray.cloud.getxray.app
 *   XRAY_PROJECT_KEY=<Jira project key, e.g. XSP>
 *
 * Output:
 *   Writes src/shared/traceability/xray-case-map.json — maps spec test titles → { issueId, key }
 *   This file is consumed by xray-reporter.js to post results after each test run.
 */

require('dotenv').config({ path: require('path').resolve(__dirname, '../../../.env') });
const fs = require('fs');
const path = require('path');
const { XrayIntegration } = require('./xray-integration');

const RAW_PROVIDER = process.env.TEST_MANAGEMENT_PROVIDER;
if (!RAW_PROVIDER) {
  console.log('⚠️  TEST_MANAGEMENT_PROVIDER not set in .env — skipping (nothing to push). Set TEST_MANAGEMENT_PROVIDER=XRAY to use this script.');
  process.exit(0);
}
const PROVIDER = RAW_PROVIDER.toUpperCase();
if (PROVIDER !== 'XRAY') {
  if (PROVIDER === 'TESTRAIL') {
    console.error('❌ TEST_MANAGEMENT_PROVIDER=TESTRAIL — run "node src/shared/integrations/push-to-testrail.js" instead, or set TEST_MANAGEMENT_PROVIDER=XRAY to use this script.');
  } else {
    console.error(`❌ Unknown TEST_MANAGEMENT_PROVIDER "${RAW_PROVIDER}" — expected TESTRAIL or XRAY.`);
  }
  process.exit(1);
}

const PROJECT_KEY = process.env.XRAY_PROJECT_KEY;
const JIRA_REF = process.env.JIRA_REF || '';

if (!PROJECT_KEY) {
  console.error('❌ XRAY_PROJECT_KEY must be set in .env');
  process.exit(1);
}

// Test case definitions — loaded from xray-test-cases.json.
// To add a new story: append an entry to xray-test-cases.json and re-run this script.
// The `specTitle` value MUST match the exact string passed to test() in the spec.
const TEST_CASES_RAW = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, '../traceability/xray-test-cases.json'), 'utf8')
);

const TEST_CASES = TEST_CASES_RAW.map((tc) => ({
  ...tc,
  refs: JIRA_REF || tc.jiraRef || ''
}));

async function main() {
  const xray = new XrayIntegration();

  console.log(`\n🚀 Pushing ${TEST_CASES.length} test case(s) to Xray...`);
  console.log(`   Project: ${PROJECT_KEY}\n`);

  const caseMap = {}; // specTitle → { issueId, key }

  for (const tc of TEST_CASES) {
    const existing = await xray.findTestByTitle(PROJECT_KEY, tc.title);

    let result;
    if (existing) {
      console.log(`   ⟳  Updating existing test ${existing.key}: ${tc.title}`);
      await xray.updateTestCase(existing.key, tc);
      result = existing;
    } else {
      result = await xray.createTestCase(PROJECT_KEY, tc);
    }

    caseMap[tc.specTitle] = { issueId: result.issueId, key: result.key };
  }

  const mapPath = path.resolve(__dirname, '../traceability/xray-case-map.json');
  fs.writeFileSync(
    mapPath,
    JSON.stringify({ projectKey: PROJECT_KEY, cases: caseMap }, null, 2),
    'utf8'
  );

  console.log(`\n✅ Done. Case map written to: ${mapPath}`);
  console.log('\n📋 Xray issue keys (update [XX-0] in the spec with these):');
  for (const [specTitle, { key }] of Object.entries(caseMap)) {
    console.log(`   [${key}]  →  ${specTitle}`);
  }
  console.log('');
}

main().catch((err) => {
  console.error('❌ Unhandled error:', err.message);
  process.exit(1);
});
