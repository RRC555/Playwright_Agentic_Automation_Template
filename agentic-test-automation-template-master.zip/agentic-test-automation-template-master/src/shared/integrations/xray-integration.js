/**
 * 🎯 Xray Cloud Integration Module
 *
 * Mirrors testrail-integration.js so push-to-xray.js / xray-reporter.js can create Manual
 * test cases in Xray, run them via a Test Execution issue, and post pass/fail per test case.
 *
 * API references (Xray Cloud):
 *  - Authenticate (REST):      POST {XRAY_BASE_URL}/api/v1/authenticate
 *  - GraphQL endpoint:         POST {XRAY_BASE_URL}/api/v2/graphql
 *  - createTest, getTests, createTestExecution, getTestRun, updateTestRunStatus mutations/queries
 *
 * Setup Instructions:
 * 1. npm install axios
 * 2. Set environment variables:
 *    - XRAY_CLIENT_ID=your-api-key-client-id
 *    - XRAY_CLIENT_SECRET=your-api-key-client-secret
 *    - XRAY_BASE_URL=https://xray.cloud.getxray.app
 *    - XRAY_PROJECT_KEY=your-jira-project-key (e.g. XSP)
 */

const axios = require('axios');

// Bearer token is valid ~24h — cache it for the life of the process instead of re-authenticating
// on every call.
const TOKEN_TTL_MS = 23 * 60 * 60 * 1000;

class XrayIntegration {
  constructor() {
    this.baseUrl = process.env.XRAY_BASE_URL || 'https://xray.cloud.getxray.app';
    this.clientId = process.env.XRAY_CLIENT_ID;
    this.clientSecret = process.env.XRAY_CLIENT_SECRET;
    this.projectKey = process.env.XRAY_PROJECT_KEY;

    if (!this.clientId || !this.clientSecret) {
      console.warn('⚠️  Xray credentials not configured. Set XRAY_CLIENT_ID, XRAY_CLIENT_SECRET');
    }

    this.client = axios.create({ baseURL: this.baseUrl, headers: { 'Content-Type': 'application/json' } });
    this.token = null;
    this.tokenObtainedAt = 0;
  }

  /**
   * Obtain (and cache) the Xray Cloud bearer token.
   * @returns {Promise<string>} JWT bearer token
   */
  async authenticate() {
    if (this.token && Date.now() - this.tokenObtainedAt < TOKEN_TTL_MS) {
      return this.token;
    }
    try {
      const response = await this.client.post('/api/v1/authenticate', {
        client_id: this.clientId,
        client_secret: this.clientSecret
      });
      // Response body is a JSON string (quoted token) — axios already parses the JSON string literal.
      this.token = response.data;
      this.tokenObtainedAt = Date.now();
      return this.token;
    } catch (error) {
      console.error('❌ Xray authentication failed:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Execute a GraphQL query/mutation against the Xray Cloud API.
   * @param {string} query - GraphQL query/mutation string
   * @param {Object} [variables]
   * @returns {Promise<Object>} The `data` field of the GraphQL response
   */
  async graphqlRequest(query, variables = {}) {
    const token = await this.authenticate();
    try {
      const response = await this.client.post(
        '/api/v2/graphql',
        { query, variables },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (response.data.errors?.length) {
        throw new Error(response.data.errors.map((e) => e.message).join('; '));
      }
      return response.data.data;
    } catch (error) {
      console.error('❌ Xray GraphQL request failed:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Find an existing Test issue by exact summary match within a project.
   * @param {string} projectKey
   * @param {string} title - exact summary to match
   * @returns {Promise<{issueId: string, key: string}|null>}
   */
  async findTestByTitle(projectKey, title) {
    // JQL `~` is a fuzzy/contains match — results are filtered client-side for an exact summary match.
    const escaped = title.replace(/"/g, '\\"');
    const jql = `project = "${projectKey}" AND summary ~ "${escaped}"`;
    const data = await this.graphqlRequest(
      `query ($jql: String, $limit: Int!) {
        getTests(jql: $jql, limit: $limit) {
          total
          results { issueId jira(fields: ["key", "summary"]) }
        }
      }`,
      { jql, limit: 20 }
    );
    const match = (data.getTests.results || []).find((t) => t.jira.summary === title);
    return match ? { issueId: match.issueId, key: match.jira.key } : null;
  }

  /**
   * Create a new Manual Test issue in Xray/Jira.
   * @param {string} projectKey
   * @param {Object} testCase - { title, steps, expected, preconditions, refs }
   * @returns {Promise<{issueId: string, key: string}>}
   */
  async createTestCase(projectKey, testCase) {
    const steps = this.buildSteps(testCase);
    const data = await this.graphqlRequest(
      `mutation ($steps: [CreateStepInput], $jira: JSON!) {
        createTest(testType: { name: "Manual" }, steps: $steps, jira: $jira) {
          test { issueId jira(fields: ["key", "summary"]) }
          warnings
        }
      }`,
      {
        steps,
        jira: {
          fields: {
            summary: testCase.title,
            description: testCase.preconditions || '',
            project: { key: projectKey }
          }
        }
      }
    );
    const { test, warnings } = data.createTest;
    if (warnings?.length) {
      console.warn(`⚠️  Xray warnings for "${testCase.title}":`, warnings.join('; '));
    }
    console.log(`✅ Test case created in Xray: ${test.jira.key} - ${testCase.title}`);
    return { issueId: test.issueId, key: test.jira.key };
  }

  /**
   * Update the Jira summary/description fields of an existing Test issue.
   * Note: this does not diff/replace Xray test steps (addTestStep/updateTestStep/removeTestStep
   * would be required for that) — step content changes still need a manual Xray UI review.
   * @param {string} issueKey
   * @param {Object} testCase
   */
  async updateTestCase(issueKey, testCase) {
    const host = process.env.JIRA_HOST;
    const email = process.env.JIRA_EMAIL;
    const token = process.env.JIRA_API_TOKEN;
    if (!host || !email || !token) {
      console.warn('⚠️  Jira credentials not configured — skipping Xray test case field update.');
      return;
    }
    try {
      await axios.put(
        `${host}/rest/api/3/issue/${issueKey}`,
        { fields: { summary: testCase.title } },
        { auth: { username: email, password: token }, headers: { 'Content-Type': 'application/json' } }
      );
      console.log(`✅ Test case updated: ${issueKey} - ${testCase.title}`);
    } catch (error) {
      console.error('❌ Failed to update test case:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Convert a test case's numbered `steps` string + `expected` into Xray CreateStepInput[].
   * @param {Object} testCase - { steps: '1. ...\n2. ...', expected: '...' }
   */
  buildSteps(testCase) {
    const lines = (testCase.steps || '')
      .split('\n')
      .map((l) => l.replace(/^\s*\d+\.\s*/, '').trim())
      .filter(Boolean);
    if (lines.length === 0) {
      return [{ action: testCase.title, result: testCase.expected || '' }];
    }
    return lines.map((action, i) => ({
      action,
      // Only the final step carries the overall expected result; earlier steps have none.
      result: i === lines.length - 1 ? testCase.expected || '' : ''
    }));
  }

  /**
   * Create a Test Execution issue linking one or more Test issues.
   * @param {string} projectKey
   * @param {string} summary
   * @param {string[]} testIssueIds
   * @returns {Promise<{issueId: string, key: string}>}
   */
  async createTestExecution(projectKey, summary, testIssueIds) {
    const data = await this.graphqlRequest(
      `mutation ($testIssueIds: [String], $jira: JSON!) {
        createTestExecution(testIssueIds: $testIssueIds, jira: $jira) {
          testExecution { issueId jira(fields: ["key"]) }
          warnings
        }
      }`,
      { testIssueIds, jira: { fields: { summary, project: { key: projectKey } } } }
    );
    const { testExecution, warnings } = data.createTestExecution;
    if (warnings?.length) {
      console.warn('⚠️  Xray warnings for test execution:', warnings.join('; '));
    }
    console.log(`✅ Test execution created in Xray: ${testExecution.jira.key} - ${summary}`);
    return { issueId: testExecution.issueId, key: testExecution.jira.key };
  }

  /**
   * Resolve the Test Run id for a given Test + Test Execution pair.
   * @param {string} testIssueId
   * @param {string} testExecIssueId
   * @returns {Promise<string>} Test Run id
   */
  async getTestRunId(testIssueId, testExecIssueId) {
    const data = await this.graphqlRequest(
      `query ($testIssueId: String, $testExecIssueId: String) {
        getTestRun(testIssueId: $testIssueId, testExecIssueId: $testExecIssueId) { id }
      }`,
      { testIssueId, testExecIssueId }
    );
    return data.getTestRun.id;
  }

  /**
   * Update a Test Run's status.
   * @param {string} testRunId
   * @param {string} status - PASSED | FAILED | TODO | EXECUTING
   */
  async updateTestRunStatus(testRunId, status) {
    await this.graphqlRequest(
      `mutation ($id: String!, $status: String!) { updateTestRunStatus(id: $id, status: $status) }`,
      { id: testRunId, status }
    );
  }

  /**
   * Map Playwright test status to an Xray Test Run status.
   * @param {string} status - Playwright status (passed, failed, skipped, timedOut)
   * @returns {string}
   */
  mapStatus(status) {
    const statusMap = {
      passed: 'PASSED',
      failed: 'FAILED',
      timedOut: 'FAILED',
      broken: 'FAILED',
      skipped: 'TODO'
    };
    return statusMap[status] || 'TODO';
  }
}

module.exports = { XrayIntegration };
