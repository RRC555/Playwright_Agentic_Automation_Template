/**
 * Playwright custom reporter — posts test results to Xray (Jira Cloud) after each run.
 *
 * How it works:
 *  1. Reads src/shared/traceability/xray-case-map.json (written by push-to-xray.js)
 *     to resolve spec test titles → Xray Test issue keys.
 *  2. For each spec test, parses a "[PROJ-123]" issue-key prefix from the title. Falls back to
 *     the case map lookup by title (with the prefix stripped) if no prefix is present.
 *  3. Creates an Xray Test Execution issue for this run, linking all mapped Test issues.
 *  4. Resolves each Test's Test Run id (scoped to this execution) and posts PASSED/FAILED/TODO.
 *
 * Wired into config/playwright.config.js as a custom reporter.
 * Only runs when TEST_MANAGEMENT_PROVIDER=XRAY and XRAY_CLIENT_ID/XRAY_CLIENT_SECRET/
 * XRAY_PROJECT_KEY are set in the environment. Set TEST_MANAGEMENT_PROVIDER=TESTRAIL to disable
 * this reporter (testrail-reporter.js handles that provider instead).
 */

require('dotenv').config({ path: require('path').resolve(__dirname, '../../../.env') });
const fs = require('fs');
const path = require('path');
const { XrayIntegration } = require('./xray-integration');

const CASE_MAP_PATH = path.resolve(__dirname, '../traceability/xray-case-map.json');
const ISSUE_KEY_REGEX = /\[([A-Z][A-Z0-9]+-\d+)\]/;

class XrayReporter {
  constructor() {
    const rawProvider = process.env.TEST_MANAGEMENT_PROVIDER;
    const provider = (rawProvider || '').toUpperCase();
    this.xray = new XrayIntegration();
    this.projectKey = process.env.XRAY_PROJECT_KEY;

    if (!rawProvider) {
      console.warn('[Xray Reporter] TEST_MANAGEMENT_PROVIDER not set in .env — skipping Xray sync (set TESTRAIL or XRAY).');
      this.enabled = false;
    } else if (!['TESTRAIL', 'XRAY'].includes(provider)) {
      console.warn(`[Xray Reporter] Unknown TEST_MANAGEMENT_PROVIDER "${rawProvider}" — expected TESTRAIL or XRAY; skipping Xray sync.`);
      this.enabled = false;
    } else if (provider !== 'XRAY') {
      // TESTRAIL is active — testrail-reporter.js handles it; nothing to log here.
      this.enabled = false;
    } else {
      this.enabled = !!(this.projectKey && process.env.XRAY_CLIENT_ID && process.env.XRAY_CLIENT_SECRET);
      if (!this.enabled) {
        console.warn('[Xray Reporter] TEST_MANAGEMENT_PROVIDER=XRAY but XRAY_CLIENT_ID/XRAY_CLIENT_SECRET/XRAY_PROJECT_KEY are incomplete — skipping Xray sync.');
      }
    }

    // Map: specTitle (stripped of [KEY] prefix) → { issueId, key }
    this.caseMap = {};
    this.results = []; // { issueId, key, status, comment }

    if (this.enabled) {
      if (fs.existsSync(CASE_MAP_PATH)) {
        const raw = JSON.parse(fs.readFileSync(CASE_MAP_PATH, 'utf8'));
        this.caseMap = raw.cases || {};
        console.log(`[Xray Reporter] Loaded ${Object.keys(this.caseMap).length} case mappings`);
      } else {
        console.warn(
          '[Xray Reporter] xray-case-map.json not found. ' +
          'Run "node src/shared/integrations/push-to-xray.js" first to create test cases in Xray.'
        );
      }
    }
  }

  onBegin(_config, _suite) {
    if (this.enabled) {
      console.log(`\n[Xray Reporter] Test run started — will post results to Xray project ${this.projectKey}`);
    }
  }

  onTestEnd(test, result) {
    if (!this.enabled) return;

    let issueKey = null;
    let issueId = null;

    const titleMatch = test.title.match(ISSUE_KEY_REGEX);
    if (titleMatch) {
      issueKey = titleMatch[1];
    }

    const strippedTitle = test.title.replace(ISSUE_KEY_REGEX, '').trim();
    const mapped = this.caseMap[strippedTitle] || this.caseMap[test.title];
    if (mapped) {
      issueId = mapped.issueId;
      issueKey = issueKey || mapped.key;
    }

    if (!issueId) {
      // No mapping found — skip silently (test not pushed to Xray)
      return;
    }

    const errorMessage = result.error
      ? `${result.error.message || ''}\n\n${result.error.stack || ''}`.substring(0, 2000)
      : '';
    const comment = result.status === 'failed'
      ? `❌ Failed in Playwright run.\n\n${errorMessage}`
      : result.status === 'skipped'
        ? '⏭️  Skipped in Playwright run.'
        : '✅ Passed in Playwright run.';

    // Upsert by issueId — for flaky tests Playwright calls onTestEnd for every attempt;
    // we only want to post the final outcome (last call wins).
    const existing = this.results.findIndex((r) => r.issueId === issueId);
    const entry = { issueId, key: issueKey, status: result.status, comment: comment.trim() };
    if (existing !== -1) {
      this.results[existing] = entry;
    } else {
      this.results.push(entry);
    }
  }

  async onEnd(_result) {
    if (!this.enabled || this.results.length === 0) return;

    const runName = `Automation — ${new Date().toISOString().split('T')[0]}`;
    const testIssueIds = [...new Set(this.results.map((r) => r.issueId))];

    console.log(`\n[Xray Reporter] Creating test execution "${runName}" with ${testIssueIds.length} test(s)...`);

    try {
      const execution = await this.xray.createTestExecution(this.projectKey, runName, testIssueIds);

      console.log(`[Xray Reporter] Posting ${this.results.length} result(s) to execution ${execution.key}...`);

      for (const r of this.results) {
        const testRunId = await this.xray.getTestRunId(r.issueId, execution.issueId);
        await this.xray.updateTestRunStatus(testRunId, this.xray.mapStatus(r.status));
      }

      const passed = this.results.filter((r) => r.status === 'passed').length;
      const failed = this.results.filter((r) => r.status === 'failed').length;
      const skipped = this.results.filter((r) => r.status === 'skipped').length;

      console.log(
        `\n[Xray Reporter] ✅ Results posted to Xray test execution ${execution.key}` +
        ` — ${passed} passed, ${failed} failed, ${skipped} skipped\n` +
        `   View: ${process.env.JIRA_HOST || ''}/browse/${execution.key}\n`
      );
    } catch (err) {
      console.error('[Xray Reporter] ❌ Failed to post results:', err.message);
    }
  }
}

module.exports = XrayReporter;
